using System.Reflection;
using HarmonyLib;

//Simple log output using Harmony 2.3 code, You see this then its working.
namespace Harmony2_3Test
{
    [HarmonyPatch(typeof(Bootstrap), "StartupShared")]
    internal class Bootstrap_StartupShared
    {
        [HarmonyPostfix]
        static void Postfix()
        {
            UnityEngine.Debug.LogWarning("[Harmony] Harmony 2.3 Installer " + Assembly.GetExecutingAssembly().GetName().Version.ToString() + " by bmgjet");
        }
    }
}
