using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("H23")]
[assembly: AssemblyDescription("Patch Harmony2.3 Files")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("bmgjet")]
[assembly: AssemblyProduct("H23")]
[assembly: AssemblyCopyright("Copyright © bmgjet 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("c4e2f9f0-5b12-4b2e-842f-0275f10ee619")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
