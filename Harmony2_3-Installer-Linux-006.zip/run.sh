#!/usr/bin/env bash
SCRIPT=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
BASEDIR=$(realpath "${SCRIPT}")
export TERM=xterm
export DOORSTOP_ENABLED=1
export DOORSTOP_TARGET_ASSEMBLY="${BASEDIR}/HarmonyMods/H23.dll"
export DOORSTOP_IGNORE_DISABLED_ENV=0
export DOORSTOP_MONO_DEBUG_ENABLED=0
export DOORSTOP_MONO_DEBUG_ADDRESS="127.0.0.1:12345"
export DOORSTOP_MONO_DEBUG_SUSPEND=0
export LD_PRELOAD="${BASEDIR}/libdoorstop.so"
export LD_LIBRARY_PATH="${BASEDIR}:${BASEDIR}/RustDedicated_Data/Plugins/x86_64"
"${SCRIPT}/RustDedicated" "$@"