public struct HarmonyModInfo
{
	public string Name;

	public string Version;
}
