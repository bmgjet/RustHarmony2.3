public interface IHarmonyModHooks
{
	void OnLoaded(OnHarmonyModLoadedArgs args);

	void OnUnloaded(OnHarmonyModUnloadedArgs args);
}
