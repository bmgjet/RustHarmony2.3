public class OnHarmonyModLoadedArgs
{
}
