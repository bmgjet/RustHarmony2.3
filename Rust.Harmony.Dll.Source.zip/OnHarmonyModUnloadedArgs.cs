public class OnHarmonyModUnloadedArgs
{
}
